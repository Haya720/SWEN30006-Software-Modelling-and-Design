package mycontroller;
/*
 * Group 6
 */
import java.util.HashMap;

import com.badlogic.gdx.math.Vector2;

import controller.CarController;
import tiles.GrassTrap;
import tiles.LavaTrap;
import tiles.MapTile;
import utilities.Coordinate;
import world.Car;
import world.WorldSpatial;

public class MyAIController extends CarController {
	Car car = null;
	// How many minimum units the wall is away from the player.
	private int wallSensitivity = 2;

	// This is initialized when the car sticks to a wall.
	private boolean isFollowingWall = false;
	// Shows the last turn direction the car takes.
	private WorldSpatial.RelativeDirection lastTurnDirection = null;
	private boolean isTurningLeft = false;
	private boolean isTurningRight = false;
	// Keeps track of the previous state
	private WorldSpatial.Direction previousState = null;

	// Car Speed to move at
	private final float CAR_SPEED = (float) 2.5;

	// Offset used to differentiate between 0 and 360 degrees
	private int EAST_THRESHOLD = 3;
	
	boolean leftHasWall;
	boolean aheadHasWall;
	boolean leftHasTrap;
	boolean aheadHasTrap;
	boolean needtoReverse = false;
	boolean canReverse = false;
	
	// Strategy
	private ReverseOutStrategy reverseOut;
	private UTurnStrategy uTurn;
	private ThreePointTurnStrategy threePoint;

	public MyAIController(Car car) {
		super(car);
		this.car = car;
		reverseOut = new ReverseOutStrategy(car, this);
		uTurn = new UTurnStrategy(car, this);
		threePoint = new ThreePointTurnStrategy(car, this);
	}
	
	
	@Override
	public void update(float delta) {
		// Gets what the car can see
		HashMap<Coordinate, MapTile> currentView = getView();
      
		checkStateChange();
		
		boolean isCarOnGrass = checkCarOnGrass(currentView);
		int grassNum = countNorthGrassTrap(currentView);
		
		if(grassNum >= 3){
			needtoReverse = true;
			if (getVelocity() < CAR_SPEED) {
				applyForwardAcceleration();
			}
			//reverseOut.applyTrunStrategy(getOrientation(), delta);
		} 
	   if(needtoReverse && !isCarOnGrass ){
		   if(!checkFollowingWall(getOrientation(), currentView)){
			   if (getVelocity() < CAR_SPEED) {
					applyForwardAcceleration();
				}
		   } else if( checkAheadWall1(getOrientation(), currentView)){
			   
			   reverseOut.applyTrunStrategy(getOrientation(), delta);
		   }	
			
		} 
	   
	  
	   
		// If you are not following a wall initially, find a wall to stick to!
		if (!isFollowingWall) {
			
			if (getVelocity() < CAR_SPEED) {
				applyForwardAcceleration();
			}
			// Turn towards the north
			if (!getOrientation().equals(WorldSpatial.Direction.NORTH)) {
				lastTurnDirection = WorldSpatial.RelativeDirection.LEFT;
				applyLeftTurn(getOrientation(), delta);
			}
			if (checkNorth(currentView)) {
				// Turn right until we go back to east!
				if (!getOrientation().equals(WorldSpatial.Direction.EAST)) {
					lastTurnDirection = WorldSpatial.RelativeDirection.RIGHT;
					applyRightTurn(getOrientation(), delta);
				} else {
					isFollowingWall = true;
				}
			}
			
		}
		// ===============================================================================================
		// Once the car is already stuck to a wall, apply the following logic
		else {
			
			
			// Readjust the car if it is misaligned.
			readjust(lastTurnDirection, delta);
			
			renewState(currentView);
			

			
			if (isTurningRight) {
				int rightRoadNum  = checkRightRoadNum(getOrientation(), currentView);
				boolean isRightExit = checkRightExit(getOrientation(), currentView);
				boolean isAheadExit = checkAheadExit(getOrientation(), currentView);
				boolean isAheadTrap = checkAheadTrap(getOrientation(), currentView);
				boolean isRightTrap = checkRightTrap(getOrientation(), currentView);
				boolean isCarOnLava = checkCarOnLava(currentView);
				
				int rightTrapLevel = checkRightTrapLevel(getOrientation(), currentView);

				
				if(rightRoadNum == 0){
					if (getVelocity() < CAR_SPEED) {
						applyForwardAcceleration();
					}
					// reverse turn
					
					reverseOut.applyTrunStrategy(getOrientation(), delta);
					
				}
				else if (rightRoadNum == 1 && !(isAheadExit || isRightExit)){
					if (getVelocity() < CAR_SPEED) {
						applyForwardAcceleration();
					}
					// 3-point turn
					threePoint.applyTrunStrategy(getOrientation(), delta);
					applyRightTurn(getOrientation(), delta);
					//readjust
					//readjust(lastTurnDirection, delta);
				}
				else if (rightRoadNum == 2 && !(isAheadTrap || isAheadTrap)){
					// U-turn
					
					float SLOWDOWN_FACTOR = 1.5f;
					Vector2 currentSpeed = car.getRawVelocity();
					float xReduction = currentSpeed.x*SLOWDOWN_FACTOR*delta;
					float yReduction = currentSpeed.y*SLOWDOWN_FACTOR*delta;
					car.setVelocity(currentSpeed.x-xReduction,currentSpeed.y-yReduction);
					
					uTurn.applyTrunStrategy(getOrientation(), delta);
					readjust(uTurn.lastTurnDirection, delta);
					
				}
				else {
					
					if (getVelocity() < CAR_SPEED) {
						applyForwardAcceleration();
						
					}
					applyRightTurn(getOrientation(), delta);
					//readjust(lastTurnDirection, delta);
					
				} 
			} 
			else if (isTurningLeft) {
				// Apply the left turn if you are not currently near a wall.
				if (getVelocity() < CAR_SPEED) {
					applyForwardAcceleration();
				}
				if (!leftHasWall) {	
					int leftTrapLevel = checkLeftTrapLevel(getOrientation(), currentView);
					if (!leftHasTrap || (leftTrapLevel == 0)) {
						applyLeftTurn(getOrientation(), delta);
						//readjust(lastTurnDirection, delta);
					} else {					
						
							isTurningLeft = false;

							if (aheadHasWall) {
								lastTurnDirection = WorldSpatial.RelativeDirection.RIGHT;
								isTurningRight = true;
							}
						
							applyLeftTurn(getOrientation(), delta);
							//readjust(lastTurnDirection, delta);
						
					}
				} else {
					isTurningLeft = false;

					if (aheadHasWall) {
						lastTurnDirection = WorldSpatial.RelativeDirection.RIGHT;
						isTurningRight = true;
					}
				}
			}
			// Try to determine whether or not the car is next to a wall.
			else if (leftHasWall) {
				// Maintain some velocity
				if (getVelocity() < CAR_SPEED) {
					applyForwardAcceleration();
				}
				// If there is wall ahead, turn right!
				if (aheadHasWall) {
					lastTurnDirection = WorldSpatial.RelativeDirection.RIGHT;
					isTurningRight = true;
				}
				if (aheadHasTrap) {
					int aheadTrapLevel = checkAheadTrapLevel(getOrientation(), currentView);
					if (aheadTrapLevel > 2) {
						lastTurnDirection = WorldSpatial.RelativeDirection.RIGHT;
						isTurningRight = true;
					}
				}
			}
			// This indicates that I can do a left turn if I am not turning
			// right
			else {
				lastTurnDirection = WorldSpatial.RelativeDirection.LEFT;
				isTurningLeft = true;
			}
		}

	}// end of update(float delta)

	private void renewState(HashMap<Coordinate, MapTile> currentView){
		leftHasWall = checkFollowingWall(getOrientation(), currentView);
		aheadHasWall = checkAheadWall(getOrientation(), currentView);
		leftHasTrap = checkFollowingTrap(getOrientation(), currentView);
		aheadHasTrap = checkAheadTrap(getOrientation(), currentView);
	}
	
	
	// ===============================================================================================
	/**
	 * Checks whether the car's state has changed or not, stops turning if it
	 * already has.
	 */
	private void checkStateChange() {
		if (previousState == null) {
			previousState = getOrientation();
		} else {
			if (previousState != getOrientation()) {
				if (isTurningLeft) {
					isTurningLeft = false;
				}
				if (isTurningRight) {
					isTurningRight = false;
				}
				previousState = getOrientation();
			}
		}
	}

	/**
	 * Turn the car counter clock wise (think of a compass going counter
	 * clock-wise)
	 */
	private void applyLeftTurn(WorldSpatial.Direction orientation, float delta) {
		switch (orientation) {
		case EAST:
			if (!getOrientation().equals(WorldSpatial.Direction.NORTH)) {
				turnLeft(delta);
			}
			break;
		case NORTH:
			if (!getOrientation().equals(WorldSpatial.Direction.WEST)) {
				turnLeft(delta);
			}
			break;
		case SOUTH:
			if (!getOrientation().equals(WorldSpatial.Direction.EAST)) {
				turnLeft(delta);
			}
			break;
		case WEST:
			if (!getOrientation().equals(WorldSpatial.Direction.SOUTH)) {
				turnLeft(delta);
			}
			break;
		default:
			break;
		}
	}

	/**
	 * Turn the car clock wise (think of a compass going clock-wise)
	 */
	private void applyRightTurn(WorldSpatial.Direction orientation, float delta) {
		switch (orientation) {
		case EAST:
			if (!getOrientation().equals(WorldSpatial.Direction.SOUTH)) {
				turnRight(delta);
			}
			break;
		case NORTH:
			if (!getOrientation().equals(WorldSpatial.Direction.EAST)) {
				turnRight(delta);
			}
			break;
		case SOUTH:
			if (!getOrientation().equals(WorldSpatial.Direction.WEST)) {
				turnRight(delta);
			}
			break;
		case WEST:
			if (!getOrientation().equals(WorldSpatial.Direction.NORTH)) {
				turnRight(delta);
			}
			break;
		default:
			break;
		}
	}

	/**
	 * Readjust the car to the orientation we are in.
	 * 
	 * @param lastTurnDirection
	 * @param delta
	 */
	public void readjust(WorldSpatial.RelativeDirection lastTurnDirection, float delta) {
		if (lastTurnDirection != null) {
			if (!isTurningRight && lastTurnDirection.equals(WorldSpatial.RelativeDirection.RIGHT)) {
				adjustRight(getOrientation(), delta);
			} else if (!isTurningLeft && lastTurnDirection.equals(WorldSpatial.RelativeDirection.LEFT)) {
				adjustLeft(getOrientation(), delta);
			}
		}

	}

	/**
	 * Try to orient myself to a degree that I was supposed to be at if I am
	 * misaligned.
	 */
	public void adjustLeft(WorldSpatial.Direction orientation, float delta) {

		switch (orientation) {
		case EAST:
			if (getAngle() > WorldSpatial.EAST_DEGREE_MIN + EAST_THRESHOLD) {
				turnRight(delta);
			}
			break;
		case NORTH:
			if (getAngle() > WorldSpatial.NORTH_DEGREE) {
				turnRight(delta);
			}
			break;
		case SOUTH:
			if (getAngle() > WorldSpatial.SOUTH_DEGREE) {
				turnRight(delta);
			}
			break;
		case WEST:
			if (getAngle() > WorldSpatial.WEST_DEGREE) {
				turnRight(delta);
			}
			break;

		default:
			break;
		}
	}

	public void adjustRight(WorldSpatial.Direction orientation, float delta) {
		switch (orientation) {
		case EAST:
			if (getAngle() > WorldSpatial.SOUTH_DEGREE && getAngle() < WorldSpatial.EAST_DEGREE_MAX) {
				turnLeft(delta);
			}
			break;
		case NORTH:
			if (getAngle() < WorldSpatial.NORTH_DEGREE) {
				turnLeft(delta);
			}
			break;
		case SOUTH:
			if (getAngle() < WorldSpatial.SOUTH_DEGREE) {
				turnLeft(delta);
			}
			break;
		case WEST:
			if (getAngle() < WorldSpatial.WEST_DEGREE) {
				turnLeft(delta);
			}
			break;

		default:
			break;
		}
	}
	
	

	private boolean checkAheadWall1(WorldSpatial.Direction orientation, HashMap<Coordinate, MapTile> currentView) {
		switch (orientation) {
		case EAST:
			return checkEast1(currentView);
		case NORTH:
			return checkNorth1(currentView);
		case SOUTH:
			return checkSouth1(currentView);
		case WEST:
			return checkWest1(currentView);
		default:
			return false;

		}
	}

	public boolean checkEast1(HashMap<Coordinate, MapTile> currentView) {
		// Check tiles to my right
		Coordinate currentPosition = new Coordinate(getPosition());
			MapTile tile = currentView.get(new Coordinate(currentPosition.x + 1, currentPosition.y));
			if (tile.getName().equals("Wall")) {
				return true;
			}	
		return false;
	}

	public boolean checkWest1(HashMap<Coordinate, MapTile> currentView) {
		// Check tiles to my left
		Coordinate currentPosition = new Coordinate(getPosition());
			MapTile tile = currentView.get(new Coordinate(currentPosition.x - 1, currentPosition.y));
			if (tile.getName().equals("Wall")) {
				return true;
			}
		return false;
	}

	public boolean checkNorth1(HashMap<Coordinate, MapTile> currentView) {
		// Check tiles to towards the top
		Coordinate currentPosition = new Coordinate(getPosition());
			MapTile tile = currentView.get(new Coordinate(currentPosition.x, currentPosition.y + 1));
			if (tile.getName().equals("Wall")) {
				return true;
			}
		return false;
	}

	public boolean checkSouth1(HashMap<Coordinate, MapTile> currentView) {
		// Check tiles towards the bottom
		Coordinate currentPosition = new Coordinate(getPosition());
			MapTile tile = currentView.get(new Coordinate(currentPosition.x, currentPosition.y - 1));
			if (tile.getName().equals("Wall")) {
				return true;
			}
		return false;
	}

	/**
	 * Check if you have a wall in front of you!
	 * 
	 * @param orientation
	 *            the orientation we are in based on WorldSpatial
	 * @param currentView
	 *            what the car can currently see
	 * @return
	 */
	private boolean checkAheadWall(WorldSpatial.Direction orientation, HashMap<Coordinate, MapTile> currentView) {
		switch (orientation) {
		case EAST:
			return checkEast(currentView);
		case NORTH:
			return checkNorth(currentView);
		case SOUTH:
			return checkSouth(currentView);
		case WEST:
			return checkWest(currentView);
		default:
			return false;

		}
	}

	/**
	 * Check if the wall is on your left hand side given your orientation
	 * 
	 * @param orientation
	 * @param currentView
	 * @return
	 */
	private boolean checkFollowingWall(WorldSpatial.Direction orientation, HashMap<Coordinate, MapTile> currentView) {
		switch (orientation) {
		case EAST:
			return checkNorth(currentView);
		case NORTH:
			return checkWest(currentView);
		case SOUTH:
			return checkEast(currentView);
		case WEST:
			return checkSouth(currentView);
		default:
			return false;
		}
	}
	
	/**
	 * 
	 * @param orientation
	 * @param currentView
	 * @return
	 */
	public boolean checkRightWall(WorldSpatial.Direction orientation, HashMap<Coordinate, MapTile> currentView) {
		switch (orientation) {
		case EAST:
			return checkSouth(currentView);
		case NORTH:
			return checkEast(currentView);
		case SOUTH:
			return checkWest(currentView);
		case WEST:
			return checkNorth(currentView);
		default:
			return false;
		}
	}
	

	/**
	 * Method below just iterates through the list and check in the correct
	 * coordinates. i.e. Given your current position is 10,10 checkEast will
	 * check up to wallSensitivity amount of tiles to the right. checkWest will
	 * check up to wallSensitivity amount of tiles to the left. checkNorth will
	 * check up to wallSensitivity amount of tiles to the top. checkSouth will
	 * check up to wallSensitivity amount of tiles below.
	 */
	public boolean checkEast(HashMap<Coordinate, MapTile> currentView) {
		// Check tiles to my right
		Coordinate currentPosition = new Coordinate(getPosition());
		for (int i = 0; i <= wallSensitivity; i++) {
			MapTile tile = currentView.get(new Coordinate(currentPosition.x + i, currentPosition.y));
			
			if (tile.getName().equals("Wall")) {
				return true;
			}
		}
		return false;
	}
	
	
	public int countNorthGrassTrap(HashMap<Coordinate, MapTile> currentView) {
		int totalDamage = 0;
		GrassTrap gt = new GrassTrap();
		Coordinate currentPosition = new Coordinate(getPosition());
		for (int i = 0; i <= wallSensitivity; i++) {
			MapTile tile = currentView.get(new Coordinate(currentPosition.x, currentPosition.y + i));
			if (tile.getName().equals("Trap")) {
				if (tile.getClass().isInstance(gt)) {
					totalDamage = totalDamage + 1;
					
				}
			}
		}
		return totalDamage;
	}
	
	public boolean checkCarOnGrass(HashMap<Coordinate, MapTile> currentView){
		GrassTrap gt = new GrassTrap();
		Coordinate currentPosition = new Coordinate(getPosition());
		for (int i = 0; i <= wallSensitivity; i++) {
			MapTile tile = currentView.get(new Coordinate(currentPosition.x + i, currentPosition.y + i));
			if (tile.getName().equals("Trap") ) {
				if (tile.getClass().isInstance(gt)) {
					return true;
				}
			}
		}
		return false;
	}
	
	public boolean checkCarOnLava(HashMap<Coordinate, MapTile> currentView){
		LavaTrap lt = new LavaTrap();
		Coordinate currentPosition = new Coordinate(getPosition());
		for (int i = 0; i <= wallSensitivity; i++) {
			MapTile tile = currentView.get(new Coordinate(currentPosition.x + i, currentPosition.y + i));
			if (tile.getName().equals("Trap") ) {
				if (tile.getClass().isInstance(lt)) {
					return true;
				}
			}
		}
		return false;
	}


	public boolean checkWest(HashMap<Coordinate, MapTile> currentView) {
		// Check tiles to my left
		Coordinate currentPosition = new Coordinate(getPosition());
		for (int i = 0; i <= wallSensitivity; i++) {
			MapTile tile = currentView.get(new Coordinate(currentPosition.x - i, currentPosition.y));
			
			if (tile.getName().equals("Wall")) {
				return true;
			}
		}
		return false;
	}

	public boolean checkNorth(HashMap<Coordinate, MapTile> currentView) {
		// Check tiles to towards the top
		Coordinate currentPosition = new Coordinate(getPosition());
		for (int i = 0; i <= wallSensitivity; i++) {
			MapTile tile = currentView.get(new Coordinate(currentPosition.x, currentPosition.y + i));
			
			if (tile.getName().equals("Wall")) {
				return true;
			}
		}
		return false;
	}

	public boolean checkSouth(HashMap<Coordinate, MapTile> currentView) {
		// Check tiles towards the bottom
		Coordinate currentPosition = new Coordinate(getPosition());
		for (int i = 0; i <= wallSensitivity; i++) {
			MapTile tile = currentView.get(new Coordinate(currentPosition.x, currentPosition.y - i));
			
			if (tile.getName().equals("Wall")) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * 
	 * @param orientation
	 * @param currentView
	 * @return
	 */

	private int checkRightRoadNum(WorldSpatial.Direction orientation, HashMap<Coordinate, MapTile> currentView) {
		switch (orientation) {
		case EAST:
			return countSouthRoad(currentView);
		case NORTH:
			return countEastRoad(currentView);
		case SOUTH:
			return countWestRoad(currentView);
		case WEST:
			return countNorthRoad(currentView);
		default:
			return 0;
		}
	}
	
	
	/**
	 * 
	 * 
	 */
	public int countSouthRoad(HashMap<Coordinate, MapTile> currentView) {
		int totalRoad = 0;
		Coordinate currentPosition = new Coordinate(getPosition());
		for (int i = 0; i <= wallSensitivity; i++) {
			MapTile tile = currentView.get(new Coordinate(currentPosition.x, currentPosition.y - i));
			if (tile.getName().equals("Road")) {
				totalRoad = totalRoad + 1;
			}
		}
		return totalRoad;
	}

	public int countNorthRoad(HashMap<Coordinate, MapTile> currentView) {
		int totalRoad = 0;
		Coordinate currentPosition = new Coordinate(getPosition());
		for (int i = 0; i <= wallSensitivity; i++) {
			MapTile tile = currentView.get(new Coordinate(currentPosition.x, currentPosition.y + i));
			if (tile.getName().equals("Road")) {
					totalRoad = totalRoad + 1;
			}
		}
		return totalRoad;
	}

	public int countWestRoad(HashMap<Coordinate, MapTile> currentView) {
		int totalRoad = 0;
		Coordinate currentPosition = new Coordinate(getPosition());
		for (int i = 0; i <= wallSensitivity; i++) {
			MapTile tile = currentView.get(new Coordinate(currentPosition.x - i, currentPosition.y));
			if (tile.getName().equals("Road")) {
					totalRoad = totalRoad + 1;
			}
		}
		return totalRoad;
	}

	public int countEastRoad(HashMap<Coordinate, MapTile> currentView) {
		int totalRoad = 0;
		Coordinate currentPosition = new Coordinate(getPosition());
		for (int i = 0; i <= wallSensitivity; i++) {
			MapTile tile = currentView.get(new Coordinate(currentPosition.x + i, currentPosition.y));
			if (tile.getName().equals("Road")) {
					totalRoad = totalRoad + 1;
			}
		}
		return totalRoad;
	}

	
	
	
	

	/**
	 * Check if you have a trap in front of you!
	 * 
	 * @param orientation
	 *            the orientation we are in based on WorldSpatial
	 * @param currentView
	 *            what the car can currently see
	 * @return
	 */
	private boolean checkAheadTrap(WorldSpatial.Direction orientation, HashMap<Coordinate, MapTile> currentView) {
		switch (orientation) {
		case EAST:
			return checkEastTrap(currentView);
		case NORTH:
			return checkNorthTrap(currentView);
		case SOUTH:
			return checkSouthTrap(currentView);
		case WEST:
			return checkWestTrap(currentView);
		default:
			return false;

		}
	}

	/**
	 * Check if the trap is on your left hand side given your orientation
	 * 
	 * @param orientation
	 * @param currentView
	 * @return
	 */
	private boolean checkFollowingTrap(WorldSpatial.Direction orientation, HashMap<Coordinate, MapTile> currentView) {
		switch (orientation) {
		case EAST:
			return checkNorthTrap(currentView);
		case NORTH:
			return checkWestTrap(currentView);
		case SOUTH:
			return checkEastTrap(currentView);
		case WEST:
			return checkSouthTrap(currentView);
		default:
			return false;
		}
	}
	
	/**
	 * 
	 * @param orientation
	 * @param currentView
	 * @return
	 */
	private boolean checkRightTrap(WorldSpatial.Direction orientation, HashMap<Coordinate, MapTile> currentView) {
		switch (orientation) {
		case EAST:
			return checkSouthTrap(currentView);
		case NORTH:
			return checkEastTrap(currentView);
		case SOUTH:
			return checkWestTrap(currentView);
		case WEST:
			return checkNorthTrap(currentView);
		default:
			return false;
		}
	}

	/**
	 * Method below just iterates through the list and check in the correct
	 * coordinates. i.e. Given your current position is 10,10 checkEastTrap will
	 * check up to wallSensitivity amount of tiles to the right. checkWestTrap
	 * will check up to wallSensitivity amount of tiles to the left.
	 * checkNorthTrap will check up to wallSensitivity amount of tiles to the
	 * top. checkSouthTrap will check up to wallSensitivity amount of tiles
	 * below.
	 */
	public boolean checkEastTrap(HashMap<Coordinate, MapTile> currentView) {
		Coordinate currentPosition = new Coordinate(getPosition());
		for (int i = 0; i <= wallSensitivity; i++) {
			MapTile tile = currentView.get(new Coordinate(currentPosition.x + i, currentPosition.y));
			if (tile.getName().equals("Trap")) {
				return true;
			}
		}
		return false;
	}

	public boolean checkWestTrap(HashMap<Coordinate, MapTile> currentView) {
		Coordinate currentPosition = new Coordinate(getPosition());
		for (int i = 0; i <= wallSensitivity; i++) {
			MapTile tile = currentView.get(new Coordinate(currentPosition.x - i, currentPosition.y));
			if (tile.getName().equals("Trap")) {
				return true;
			}
		}
		return false;
	}

	public boolean checkNorthTrap(HashMap<Coordinate, MapTile> currentView) {
		Coordinate currentPosition = new Coordinate(getPosition());
		for (int i = 0; i <= wallSensitivity; i++) {
			MapTile tile = currentView.get(new Coordinate(currentPosition.x, currentPosition.y + i));
			if (tile.getName().equals("Trap")) {
				return true;
			}
		}
		return false;
	}

	public boolean checkSouthTrap(HashMap<Coordinate, MapTile> currentView) {
		Coordinate currentPosition = new Coordinate(getPosition());
		for (int i = 0; i <= wallSensitivity; i++) {
			MapTile tile = currentView.get(new Coordinate(currentPosition.x, currentPosition.y - i));
			if (tile.getName().equals("Trap")) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * 
	 * @param orientation
	 * @param currentView
	 * @return
	 */
	private boolean checkRightExit(WorldSpatial.Direction orientation, HashMap<Coordinate, MapTile> currentView) {
		switch (orientation) {
		case EAST:
			return checkSouthExit(currentView);
		case NORTH:
			return checkEastExit(currentView);
		case SOUTH:
			return checkWestExit(currentView);
		case WEST:
			return checkNorthExit(currentView);
		default:
			return false;
		}
	}
	
	private boolean checkAheadExit(WorldSpatial.Direction orientation, HashMap<Coordinate, MapTile> currentView) {
		switch (orientation) {
		case EAST:
			return checkEastExit(currentView);
		case NORTH:
			return checkNorthExit(currentView);
		case SOUTH:
			return checkSouthExit(currentView);
		case WEST:
			return checkWestExit(currentView);
		default:
			return false;

		}
	}


	/**
	 * Method below just iterates through the list and check in the correct
	 * coordinates. i.e. Given your current position is 10,10 checkEastTrap will
	 * check up to wallSensitivity amount of tiles to the right. checkWestTrap
	 * will check up to wallSensitivity amount of tiles to the left.
	 * checkNorthTrap will check up to wallSensitivity amount of tiles to the
	 * top. checkSouthTrap will check up to wallSensitivity amount of tiles
	 * below.
	 */
	public boolean checkEastExit(HashMap<Coordinate, MapTile> currentView) {
		Coordinate currentPosition = new Coordinate(getPosition());
		for (int i = 0; i <= wallSensitivity; i++) {
			MapTile tile = currentView.get(new Coordinate(currentPosition.x + i, currentPosition.y));
			
			if (tile.getName().equals("Utility")) {
				
				return true;
			}
		}
		return false;
	}

	public boolean checkWestExit(HashMap<Coordinate, MapTile> currentView) {
		Coordinate currentPosition = new Coordinate(getPosition());
		for (int i = 0; i <= wallSensitivity; i++) {
			MapTile tile = currentView.get(new Coordinate(currentPosition.x - i, currentPosition.y));
			
			if (tile.getName().equals("Utility")) {
				
				return true;
			}
		}
		return false;
	}

	public boolean checkNorthExit(HashMap<Coordinate, MapTile> currentView) {
		Coordinate currentPosition = new Coordinate(getPosition());
		for (int i = 0; i <= wallSensitivity; i++) {
			MapTile tile = currentView.get(new Coordinate(currentPosition.x, currentPosition.y + i));
			
			if (tile.getName().equals("Utility")) {
				return true;
			}
		}
		return false;
	}

	public boolean checkSouthExit(HashMap<Coordinate, MapTile> currentView) {
		Coordinate currentPosition = new Coordinate(getPosition());
		for (int i = 0; i <= wallSensitivity; i++) {
			MapTile tile = currentView.get(new Coordinate(currentPosition.x, currentPosition.y - i));
			
			if (tile.getName().equals("Utility")) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 
	 * @param orientation
	 * @param currentView
	 * @return
	 */
	private int checkLeftTrapLevel(WorldSpatial.Direction orientation, HashMap<Coordinate, MapTile> currentView) {
		// applyReverseAcceleration();
		switch (orientation) {
		case EAST:
			return countNorthTrap(currentView);
		case NORTH:
			return countWestTrap(currentView);
		case SOUTH:
			return countEastTrap(currentView);
		case WEST:
			return countSouthTrap(currentView);
		default:
			return 0;
		}
	}

	/**
	 * 
	 * @param orientation
	 * @param currentView
	 * @return
	 */
	private int checkAheadTrapLevel(WorldSpatial.Direction orientation, HashMap<Coordinate, MapTile> currentView) {
		// applyReverseAcceleration();
		switch (orientation) {
		case EAST:
			return countEastTrap(currentView);
		case NORTH:
			return countNorthTrap(currentView);
		case SOUTH:
			return countSouthTrap(currentView);
		case WEST:
			return countWestTrap(currentView);
		default:
			return 0;
		}
	}
	
	/**
	 * 
	 * @param orientation
	 * @param currentView
	 * @return
	 */
	private int checkRightTrapLevel(WorldSpatial.Direction orientation, HashMap<Coordinate, MapTile> currentView) {
		// applyReverseAcceleration();
		switch (orientation) {
		case EAST:
			return countSouthTrap(currentView);
		case NORTH:
			return countEastTrap(currentView);
		case SOUTH:
			return countWestTrap(currentView);
		case WEST:
			return countNorthTrap(currentView);
		default:
			return 0;
		}
	}

	/**
	 * 
	 * 
	 */
	public int countSouthTrap(HashMap<Coordinate, MapTile> currentView) {
		int totalDamage = 0;
		LavaTrap lt = new LavaTrap();
		Coordinate currentPosition = new Coordinate(getPosition());
		for (int i = 0; i <= wallSensitivity; i++) {
			MapTile tile = currentView.get(new Coordinate(currentPosition.x, currentPosition.y - i));
			if (tile.getName().equals("Trap")) {
				if (tile.getClass().isInstance(lt)) {
					totalDamage = totalDamage + 1;
					
				}
			}
		}
		return totalDamage;
	}

	public int countNorthTrap(HashMap<Coordinate, MapTile> currentView) {
		int totalDamage = 0;
		LavaTrap lt = new LavaTrap();
		Coordinate currentPosition = new Coordinate(getPosition());
		for (int i = 0; i <= wallSensitivity; i++) {
			MapTile tile = currentView.get(new Coordinate(currentPosition.x, currentPosition.y + i));
			if (tile.getName().equals("Trap")) {
				if (tile.getClass().isInstance(lt)) {
					totalDamage = totalDamage + 1;
				
				}
			}
		}
		return totalDamage;
	}

	public int countWestTrap(HashMap<Coordinate, MapTile> currentView) {
		int totalDamage = 0;
		LavaTrap lt = new LavaTrap();
		Coordinate currentPosition = new Coordinate(getPosition());
		for (int i = 0; i <= wallSensitivity; i++) {
			MapTile tile = currentView.get(new Coordinate(currentPosition.x - i, currentPosition.y));
			if (tile.getName().equals("Trap")) {
				if (tile.getClass().isInstance(lt)) {
					totalDamage = totalDamage + 1;
					
				}
			}
		}
		return totalDamage;
	}

	public int countEastTrap(HashMap<Coordinate, MapTile> currentView) {
		int totalDamage = 0;
		LavaTrap lt = new LavaTrap();

		Coordinate currentPosition = new Coordinate(getPosition());
		for (int i = 0; i <= wallSensitivity; i++) {
			MapTile tile = currentView.get(new Coordinate(currentPosition.x + i, currentPosition.y));
			if (tile.getName().equals("Trap")) {
				if (tile.getClass().isInstance(lt)) {
					totalDamage = totalDamage + 1;
					
				}

			}
		}
		return totalDamage;
	}
	
	

}// end of class
