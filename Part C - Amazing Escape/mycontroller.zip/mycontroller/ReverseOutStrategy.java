package mycontroller;
/*
 * Group 6
 */
import world.Car;
import world.WorldSpatial;

public class ReverseOutStrategy extends TurnStrategy{
//	private float reverseSpeed;
	
	public ReverseOutStrategy(Car car, 	MyAIController controller){
		super(car, controller);
	}

	public void applyTrunStrategy(WorldSpatial.Direction orientation, float delta){
		//car.applyReverseAcceleration();
		for(int i = 0; i < 10000; i++){
			car.applyReverseAcceleration();
		}
	}
}
