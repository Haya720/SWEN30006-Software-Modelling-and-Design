package mycontroller;
/*
 * Group 6
 */
import com.badlogic.gdx.math.Vector2;


import world.Car;
import world.WorldSpatial;

public class ThreePointTurnStrategy extends TurnStrategy {


	public ThreePointTurnStrategy(Car car, MyAIController controller) {
		super(car, controller);
		// TODO Auto-generated constructor stub
		
	}
	
	public void applyTrunStrategy(WorldSpatial.Direction orientation, float delta){
		if(car.getVelocity() > 0) {
			float SLOWDOWN_FACTOR = 3.5f;
			Vector2 currentSpeed = car.getRawVelocity();
			float xReduction = currentSpeed.x*SLOWDOWN_FACTOR*delta;
			float yReduction = currentSpeed.y*SLOWDOWN_FACTOR*delta;
			car.setVelocity(currentSpeed.x-xReduction,currentSpeed.y-yReduction);
			
			
		}
			
		switch(orientation){
		case EAST:
			if(!controller.getOrientation().equals(WorldSpatial.Direction.SOUTH)){
				car.applyReverseAcceleration();
				car.turnLeft(delta);
				if(!controller.getOrientation().equals(WorldSpatial.Direction.WEST)){
					car.applyForwardAcceleration();
					car.turnRight(delta);
				}
			}
			break;
		case NORTH:
			if(!controller.getOrientation().equals(WorldSpatial.Direction.EAST)){
				//car.applyReverseAcceleration();
				for(int i = 0; i < 1000000; i++){
					
						car.applyReverseAcceleration();
					
					
				}
					
				car.turnLeft(delta);
				if(!controller.getOrientation().equals(WorldSpatial.Direction.SOUTH)){
					
						
						car.applyForwardAcceleration();
						car.turnRight(delta);
					
					
				}
			}
			break;
		case SOUTH:
			if(!controller.getOrientation().equals(WorldSpatial.Direction.WEST)){
				car.applyReverseAcceleration();
				car.turnLeft(delta);
				if(!controller.getOrientation().equals(WorldSpatial.Direction.NORTH)){
					car.applyForwardAcceleration();
					car.turnRight(delta);
				}
			}
			break;
		case WEST:
			if(!controller.getOrientation().equals(WorldSpatial.Direction.NORTH)){
				car.applyReverseAcceleration();
				car.turnLeft(delta);
				if(!controller.getOrientation().equals(WorldSpatial.Direction.EAST)){
					car.applyForwardAcceleration();
					car.turnRight(delta);
				}
			}
			
		}
		
	
		
	}

}
