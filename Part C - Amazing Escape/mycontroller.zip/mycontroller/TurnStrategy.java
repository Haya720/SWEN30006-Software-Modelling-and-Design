package mycontroller;
/*
 * Group 6
 */
import controller.CarController;
import world.Car;
import world.WorldSpatial;

public abstract class TurnStrategy {
	protected Car car;
	protected CarController controller;
	
	public TurnStrategy(Car car, MyAIController controller) {
		this.car = car;
		this.controller = controller;
	}
	public void applyTrunStrategy(WorldSpatial.Direction currentorientation, float delta){
		
	}

}
