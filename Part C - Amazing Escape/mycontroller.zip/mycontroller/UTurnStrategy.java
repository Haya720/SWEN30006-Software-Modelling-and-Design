package mycontroller;
/*
 * Group 6
 */


import world.Car;
import world.WorldSpatial;

public class UTurnStrategy extends TurnStrategy{
	
	
	
	public WorldSpatial.RelativeDirection lastTurnDirection = null;
	
	public UTurnStrategy(Car car, MyAIController controller) {
		super(car, controller);
		// TODO Auto-generated constructor stub
	}

	public void applyTrunStrategy(WorldSpatial.Direction orientation, float delta){
		
	
		switch(orientation){
		case EAST:
			if(!controller.getOrientation().equals(WorldSpatial.Direction.SOUTH)){
				lastTurnDirection = WorldSpatial.RelativeDirection.RIGHT;
				car.turnRight(delta);
			}
			break;
		case NORTH:
			if(!controller.getOrientation().equals(WorldSpatial.Direction.EAST)){
				lastTurnDirection = WorldSpatial.RelativeDirection.RIGHT;
				car.turnRight(delta);
			}
			break;
		case SOUTH:
			if(!controller.getOrientation().equals(WorldSpatial.Direction.WEST)){
				lastTurnDirection = WorldSpatial.RelativeDirection.LEFT;
				car.turnRight(delta);
			}
			break;
		case WEST:
			if(!controller.getOrientation().equals(WorldSpatial.Direction.NORTH)){
				lastTurnDirection = WorldSpatial.RelativeDirection.LEFT;
				car.turnRight(delta);
			}
			break;
		default:
			break;
		
		}
		
		
	}
	
	
	
	
	
	


}
