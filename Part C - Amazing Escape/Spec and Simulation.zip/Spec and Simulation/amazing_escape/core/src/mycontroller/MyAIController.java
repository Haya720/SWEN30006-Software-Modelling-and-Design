package mycontroller;

import controller.CarController;
import world.Car;

public class MyAIController extends CarController{

	public MyAIController(Car car) {
		super(car);
	}

	@Override
	public void update(float delta) {
		// TODO Auto-generated method stub
		
	}

}
