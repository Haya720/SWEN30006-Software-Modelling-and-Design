<?xml version="1.0" encoding="UTF-8"?>
<tileset name="wallsandroofs" tilewidth="32" tileheight="32" tilecount="256" columns="16">
 <image source="wallsandroofs.png" width="512" height="512"/>
 <tile id="65">
  <properties>
   <property name="collidable" type="bool" value="true"/>
  </properties>
 </tile>
</tileset>
