<?xml version="1.0" encoding="UTF-8"?>
<tileset name="meta" tilewidth="32" tileheight="32" margin="1" tilecount="2" columns="2">
 <image source="meta.png" width="67" height="34"/>
 <tile id="0">
  <properties>
   <property name="exit" type="bool" value="true"/>
  </properties>
 </tile>
 <tile id="1">
  <properties>
   <property name="startLocation" type="bool" value="true"/>
  </properties>
 </tile>
</tileset>
